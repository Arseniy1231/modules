<?php
// Heading
$_['heading_title'] = 'Недавно просмотренные';