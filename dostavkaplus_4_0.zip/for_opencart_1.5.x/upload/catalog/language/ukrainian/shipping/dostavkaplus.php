<?php
// Text
$_['text_title'] = 'Доставка плюс';

$_['text_free'] = 'безкоштовно';

$_['error_description_zone']        = '<span style="color:red;">Цей спосіб доставки не доступний у вибраному регіоні.</span>';
$_['error_description_quantity']    = '<span style="color:red;">Цей спосіб оплати не доступний, тому що в замовленні є товари, яких немає на складі.</span>';
$_['error_description_total']       = '<span style="color:red;">Мін. вартість замовлення для цього способу доставки %s, щоб він став доступним, додайте до замовлення товари на суму %s</span>';
$_['error_description_weight']      = '<span style="color:red;">Макс. вага замовлення для цього способу доставки %s, щоб він став доступним, заберіть з корзини частину товарів вагою %s</span>';

?>