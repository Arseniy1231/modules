<?php
// Text
$_['text_title'] = 'Доставка плюс';

$_['text_free'] = 'бесплатно';

$_['error_description_zone']        = '<span style="color:red;">Этот способ доставки не доступен в выбранном регионе.</span>';
$_['error_description_quantity']    = '<span style="color:red;">Этот способ оплаты не доступен, потому что в заказе есть товары, которых нет на складе.</span>';
$_['error_description_total']       = '<span style="color:red;">Мин. стоимость заказа для этого способа доставки %s, чтобы он стал доступен, добавьте в заказ товары на сумму %s</span>';
$_['error_description_weight']      = '<span style="color:red;">Макс. вес заказа для этого способа доставки %s, чтобы он стал доступен, уберите из корзины часть товаров весом %s</span>';

?>