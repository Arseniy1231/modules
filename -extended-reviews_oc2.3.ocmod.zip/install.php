<?php
/**
 * Extended Reviews
 * @author: nikita-sp.com.ua
 */

$chk = $this->db->query("SHOW COLUMNS FROM `" . DB_PREFIX . "review` WHERE `Field` = 'advant'");

if (!$chk->num_rows) {
	$this->db->query("ALTER TABLE `" . DB_PREFIX . "review` ADD `email` varchar(96) NOT NULL, ADD `advant` text NOT NULL, ADD `disadvant` text NOT NULL, ADD `positive` int(11) NOT NULL DEFAULT '0', ADD `negative` int(11) NOT NULL DEFAULT '0'");
	$this->db->query("CREATE TABLE IF NOT EXISTS `oc_review_reply` (`review_reply_id` int(11) NOT NULL AUTO_INCREMENT, `review_id` int(11) NOT NULL, `customer_id` int(11) NOT NULL, `author` varchar(64) NOT NULL, `text` text NOT NULL, `status` tinyint(1) NOT NULL DEFAULT '0', `date_added` datetime NOT NULL, PRIMARY KEY (`review_reply_id`)) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1;");
}
