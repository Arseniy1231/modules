<?php
// Text
$_['text_new_subject']          = 'You received a response to a comment on the site %s';
$_['text_new_greeting']         = 'Thank you for your interest in %s. This email was sent to you because you asked to be notified of replies to your comment.';
$_['text_new_link']             = 'To view the answer to your comment, please click on the link:';
$_['text_new_footer']           = 'If you have any questions, please reply to this email.';
$_['text_new_powered']			= '';