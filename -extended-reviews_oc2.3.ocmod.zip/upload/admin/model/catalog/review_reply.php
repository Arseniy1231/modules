<?php
class ModelCatalogReviewReply extends Model {
	public function addReviewReply($data) {
		$this->db->query("INSERT INTO " . DB_PREFIX . "review_reply SET review_id = '" . (int)$data['review_id'] . "', author = '" . $this->db->escape($data['author']) . "', text = '" . $this->db->escape($data['text']) . "', status = '" . (int)$data['status'] . "', date_added = '".$this->db->escape($data['date_added'])."'");

		$this->cache->delete('product');
	}

	public function editReviewReply($review_reply_id, $data) {
		$this->db->query("UPDATE " . DB_PREFIX . "review_reply SET review_id = '" . (int)$data['review_id'] . "', author = '" . $this->db->escape($data['author']) . "', text = '" . $this->db->escape($data['text']) . "', status = '" . (int)$data['status'] . "', date_added = '".$this->db->escape($data['date_added'])."' WHERE review_reply_id = '" . (int)$review_reply_id . "'");

		$this->cache->delete('product');
	}

	public function deleteReviewReply($review_reply_id) {
		$this->db->query("DELETE FROM " . DB_PREFIX . "review_reply WHERE review_reply_id = '" . (int)$review_reply_id . "'");

		$this->cache->delete('product');
	}

	public function getReviewReply($review_reply_id) {
		$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "review_reply WHERE review_reply_id = '" . (int)$review_reply_id . "'");

		return $query->row;
	}

	public function getReviewReplies($data = array()) {
		$sql = "SELECT rr.*, r.text as review FROM " . DB_PREFIX . "review_reply rr LEFT JOIN " . DB_PREFIX . "review r ON (rr.review_id = r.review_id) ";

		$sort_data = array(
			'r.text',
			'rr.author',
			'rr.status',
			'rr.date_added'
		);

		if (isset($data['sort']) && in_array($data['sort'], $sort_data)) {
			$sql .= " ORDER BY " . $data['sort'];
		} else {
			$sql .= " ORDER BY date_added";
		}

		if (isset($data['order']) && ($data['order'] == 'DESC')) {
			$sql .= " DESC";
		} else {
			$sql .= " ASC";
		}

		if (isset($data['start']) || isset($data['limit'])) {
			if ($data['start'] < 0) {
				$data['start'] = 0;
			}

			if ($data['limit'] < 1) {
				$data['limit'] = 20;
			}

			$sql .= " LIMIT " . (int)$data['start'] . "," . (int)$data['limit'];
		}

		$query = $this->db->query($sql);

		return $query->rows;
	}

	public function getTotalReviewReplies() {
		$query = $this->db->query("SELECT COUNT(*) AS total FROM " . DB_PREFIX . "review_reply");

		return $query->row['total'];
	}

	public function getTotalReviewRepliessAwaitingApproval() {
		$query = $this->db->query("SELECT COUNT(*) AS total FROM " . DB_PREFIX . "review_reply WHERE status = '0'");

		return $query->row['total'];
	}
}