<?php
// Heading
$_['heading_title']       = 'Ответы на отзывы';

// Text
$_['text_list']         = 'Ответы на отзывы';
$_['text_form']         = 'Редактировать ответ на отзыв';
$_['text_add']          = 'Добавить';
$_['text_edit']         = 'Редактирование';
$_['text_success']      = 'Список ответов обновлен!';
$_['text_review_link']  = 'Ссылка на комментарий';

// Column
$_['column_review']     = 'Отзыв';
$_['column_author']     = 'Автор';
$_['column_status']     = 'Статус';
$_['column_date_added'] = 'Добавлено';
$_['column_action']     = 'Действие';

// Entry
$_['entry_review_id']   = 'ID Отзыва:';
$_['entry_author']      = 'Автор:';
$_['entry_date_added'] = 'Добавлено:';
$_['entry_status']      = 'Статус:';
$_['entry_text']        = 'Текст:';

// Error
$_['error_permission']  = 'У Вас нет прав для изменения ответов!';
$_['error_review_id']   = 'Требуется указать ID отзыва!';
$_['error_author']      = 'Имя автора должно быть от 3 до 64 символов!';
$_['error_text']        = 'Текст ответа должен содержать хотя бы 1 символ!';