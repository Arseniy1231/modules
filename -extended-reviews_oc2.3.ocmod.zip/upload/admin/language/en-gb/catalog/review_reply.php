<?php
// Heading
$_['heading_title']       = 'Review replies';

// Text
$_['text_list']         = 'Review replies';
$_['text_form']         = 'Edit review reply';
$_['text_success']      = 'The replies were updated!';
$_['text_review_link']  = 'Link to review';
$_['text_add']          = 'Add review reply';
$_['text_edit']         = 'Edit review reply';

// Column
$_['column_review']     = 'Review';
$_['column_author']     = 'Author';
$_['column_status']     = 'Status';
$_['column_date_added'] = 'Added';
$_['column_action']     = 'Action';

// Entry
$_['entry_review_id']   = 'Review ID:';
$_['entry_author']      = 'Author:';
$_['entry_date_added'] = 'Added:';
$_['entry_status']      = 'Status:';
$_['entry_text']        = 'Text:';

// Error
$_['error_permission']  = 'Warning: You do not have permission to modify reviews!';
$_['error_review_id']     = 'Review ID is required!';
$_['error_author']      = 'Author must be between 3 and 64 characters!';
$_['error_text']        = 'Review Text must be at least 1 character!';