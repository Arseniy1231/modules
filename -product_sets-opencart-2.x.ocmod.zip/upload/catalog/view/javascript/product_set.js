$(document).ready(function(){
	updateSetTotal();
	$(".setModal").find(".modal-body.row .item").first().addClass("hidden");

	$('.setBox .carousel-inner').bind("DOMSubtreeModified", function(){
		if($(this).children().length < 2){
			$(this).children().find(".removeFromSet").addClass("hidden");
		}else{
			$(this).find(".removeFromSet").removeClass("hidden");
		}
	});
});
/* SAVE PRODUCT_ID FOR REPLACE FUNCTION */
var replaceSet = false;
/* CLEAR VARIABLE IF MODAL IS CLOSED */
$(".modal.setModal").on('hidden.bs.modal', function (e){
	replaceSet = false;
});
function replaceFromSet(product_id){
	$("#product_set_modal").modal("show");
	replaceSet = product_id;
}
function removeFromSet(product_id){
	if(replaceSet) replaceSet = false;
	$("#product_set_modal .item-"+product_id).removeClass("hidden");
	$(".product_set_products .item.item-"+product_id).remove();
	$(".product_set_products .item:first-child").addClass("active");
	if($("#product_set_modal .item").not(".hidden").length < 1){
		$("#product_set_modal .emptySet").removeClass("hidden");
	}else{
		$("#product_set_modal .emptySet").addClass("hidden");
	}
	updateSetTotal();
}
function addToSet(product_id){
	if(replaceSet) removeFromSet(replaceSet);
	var carouselHTML = $.trim($(".product_set_products .carousel-inner").html());
	var newElementClass = "item item-"+product_id;
	if(!carouselHTML.length){
		newElementClass = "active "+newElementClass;
	}
	var element = "<div class=\""+newElementClass+"\">"+$("#product_set_modal .item-"+product_id+" .hidden").html()+"</div>";

	var html = carouselHTML+element;
	updateSetCarousel(html);
	$("#product_set_modal .item-"+product_id).addClass("hidden");
	if($("#product_set_modal .item").not(".hidden").length < 1){
		$("#product_set_modal .emptySet").removeClass("hidden");
	}else{
		$("#product_set_modal .emptySet").addClass("hidden");
	}
}
function updateSetCarousel(html){
	$(".product_set_products").carousel("pause").removeData();
	$(".product_set_products .carousel-inner").html(html);
	$(".product_set_products").carousel().carousel('pause');
	$("#product_set_modal").modal("hide");
	updateSetTotal();
}
function updateSetTotal(){
	var oldTotal = 0;
	var newTotal = 0;
	var savings = 0;

	// Get main product price
	newTotal += Number($(".setBox .main-product").find(".new-price").text().replace(/[^0-9\.]+/g,""));
	if($(".setBox .main-product").find(".old-price").length){
		oldTotal += Number($(".setBox .main-product").find(".old-price").text().replace(/[^0-9\.]+/g,""));
	}else{
		oldTotal += newTotal;
	}
	$("#product_set .carousel-inner .item").each(function(){
		oldTotal += Number($(this).find(".old-price").text().replace(/[^0-9\.]+/g,""));
		newTotal += Number($(this).find(".new-price").text().replace(/[^0-9\.]+/g,""));
	});
	savings = oldTotal - newTotal;

	// Output
	$(".setBox .buySet .old-price-sum span").text(oldTotal);
	$(".setBox .buySet .new-price-sum span").text(newTotal);
	$(".setBox .buySet .set-savings span").text(savings);
}
function buyProductSet(){	var product_set_id = $(".setBox input.product_set_id").val();
	var product_id = $(".setBox input.product_id").val();

	var productSetProducts = new Array();
	productSetProducts.push(parseInt(product_id));
	$(".setBox .product_set_products input.product_set_product_id").each(function(){
		productSetProducts.push(parseInt($(this).val()));
	});
	$.ajax({
		url: 'index.php?route=checkout/cart/addProductSet',
		type: 'post',
		data: 'product_ids=' + productSetProducts + '&product_set_id=' + product_set_id + '&product_id='+product_id,
		dataType: 'json',
		success: function(json) {
			if (json['success']) {
				$('#content').parent().before('<div class="alert alert-success"><i class="fa fa-check-circle"></i> ' + json['success'] + '<button type="button" class="close" data-dismiss="alert">&times;</button></div>');
				$('#cart-total').html(json['total']);
				$('html, body').animate({ scrollTop: 0 }, 'slow');
				$('#cart > ul').load('index.php?route=common/cart/info ul li');
			}
		}
	});
}