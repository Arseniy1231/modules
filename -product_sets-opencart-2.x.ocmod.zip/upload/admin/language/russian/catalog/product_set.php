<?php
// Heading
$_['heading_title']       = 'Комплекты';

// Text
$_['text_success']        = 'Успешно: вы обновили список комплектов!';
$_['text_list']           = 'Список комплектов';
$_['text_add']            = 'Добавить комплект';
$_['text_edit']           = 'Изменить комплект';

// Column
$_['column_name']         = 'Название комплекта';
$_['column_action']       = 'Действие';
$_['column_product']       = 'Продукт';
$_['column_sale']          = 'Скидка';
$_['column_sort_order']    = 'Порядок сортировки';

// Entry
$_['entry_name']          = 'Название продукта';
$_['entry_products']      = 'Продукты';

// Button
$_['button_product_add']  = 'Добавить продукт';

// Error
$_['error_permission']    = 'Внимание: У вас нет доступа для редактирования списка комплектов!';
$_['error_name']          = 'Название комплекта должно быть между 1 и 128 символами!';