<?php
// Heading
$_['heading_title']       = 'Product sets';

// Text
$_['text_success']        = 'Success: You have modified product sets!';
$_['text_list']           = 'Product sets List';
$_['text_add']            = 'Add Product Set';
$_['text_edit']           = 'Edit Product Set';

// Column
$_['column_name']         = 'Product Set Name';
$_['column_action']       = 'Action';
$_['column_product']       = 'Product';
$_['column_sale']          = 'Sale';
$_['column_sort_order']    = 'Sort Order';

// Entry
$_['entry_name']          = 'Product Set Name';
$_['entry_products']      = 'Products';

// Button
$_['button_product_add']  = 'Add Product';

// Error
$_['error_permission']    = 'Warning: You do not have permission to modify product sets!';
$_['error_name']          = 'Option Name must be between 1 and 128 characters!';