<?php
class ModelCatalogProductSet extends Model {
	public function addProductSet($data) {
		$this->event->trigger('pre.admin.product_set.add', $data);

		$this->db->query("INSERT INTO `" . DB_PREFIX . "product_set` SET name = '" . $this->db->escape($data['name']) . "'");

		$product_set_id = $this->db->getLastId();

		foreach ($data['products'] as $product) {
			$this->db->query("INSERT INTO " . DB_PREFIX . "product_set_products SET product_set_id = '" . (int)$product_set_id . "', product_id = '" . (int)$product['product_id'] . "', product_name = '" . $this->db->escape($product['product_name']) . "', sale = '" . (int)($product['sale']) . "', sort_order = '" . (int)($product['sort_order']) . "'");
		}

		$this->event->trigger('post.admin.product_set.add', $product_set_id);

		return $product_set_id;
	}

	public function editProductSet($product_set_id, $data) {
		$this->event->trigger('pre.admin.product_set.edit', $data);

		$this->db->query("UPDATE `" . DB_PREFIX . "product_set` SET name = '" . $this->db->escape($data['name']) . "' WHERE product_set_id = '" . (int)$product_set_id . "'");

		$this->db->query("DELETE FROM " . DB_PREFIX . "product_set_products WHERE product_set_id = '" . (int)$product_set_id . "'");

		foreach ($data['products'] as $product) {
			$this->db->query("INSERT INTO " . DB_PREFIX . "product_set_products SET product_set_id = '" . (int)$product_set_id . "', product_id = '" . (int)$product['product_id'] . "', product_name = '" . $this->db->escape($product['product_name']) . "', sale = '" . (int)($product['sale']) . "', sort_order = '" . (int)($product['sort_order']) . "'");
		}

		$this->event->trigger('post.admin.product_set.edit', $product_set_id);
	}

	public function deleteProductSet($product_set_id) {
		$this->event->trigger('pre.admin.product_set.delete', $product_set_id);

		$this->db->query("DELETE FROM `" . DB_PREFIX . "product_set` WHERE product_set_id = '" . (int)$product_set_id . "'");
		$this->db->query("DELETE FROM " . DB_PREFIX . "product_set_products WHERE product_set_id = '" . (int)$product_set_id . "'");
		$this->db->query("UPDATE " . DB_PREFIX . "product SET product_set_id = '0' WHERE product_set_id = '" . (int)$product_set_id . "'");

		$this->event->trigger('post.admin.product_set.delete', $product_set_id);
	}

	public function getProductSet($product_set_id) {
		$query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "product_set` ps LEFT JOIN " . DB_PREFIX . "product_set_products psp ON (ps.product_set_id = psp.product_set_id) WHERE ps.product_set_id = '" . (int)$product_set_id . "'");

		return $query->row;
	}

	public function getProductSets($data = array()) {
		$sql = "SELECT * FROM `" . DB_PREFIX . "product_set`";

		if (!empty($data['filter_name'])) {
			$sql .= " WHERE name LIKE '" . $this->db->escape($data['filter_name']) . "%'";
		}

		$sql .= " ORDER BY name";

		if (isset($data['start']) || isset($data['limit'])) {
			if ($data['start'] < 0) {
				$data['start'] = 0;
			}

			if ($data['limit'] < 1) {
				$data['limit'] = 20;
			}

			$sql .= " LIMIT " . (int)$data['start'] . "," . (int)$data['limit'];
		}

		$query = $this->db->query($sql);

		return $query->rows;
	}

	public function getProductSetProducts($product_set_id) {
		$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "product_set_products WHERE product_set_id = '" . (int)$product_set_id . "'");

		return $query->rows;
	}

	public function getTotalProductSets() {
		$query = $this->db->query("SELECT COUNT(*) AS total FROM `" . DB_PREFIX . "product_set`");

		return $query->row['total'];
	}

}