<?php get_header(); ?>

		<section class="main">
			<div class="post">
			<h2><?php _e('404 Not Found','site5framework') ?></h2>
			<p style="text-align:center;"><?php _e("The article you were looking for was not found, but maybe try looking again!", "site5framework"); ?></p>
			</div>
		</section>

<div class="clear"></div>

<?php get_footer(); ?>