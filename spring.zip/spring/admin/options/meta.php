<?php
    $options[] = array( "name" => "Meta",
    					"sicon" => "metatag.png",
						"type" => "heading");

    $options[] = array( "name" => "Meta Description",
						"id" => SN."metadescription",
						"std" => "full functionable, premium wordpress theme solution for your website.",
						"type" => "textarea");

    $options[] = array( "name" => "Meta Keywords",
						"std" => "proffesional wordpress theme, flexible wordpress theme, wordpress all in one theme, premium wordpress theme ",
						"id" => SN."metakeywords",
                        "type" => "textarea");

?>