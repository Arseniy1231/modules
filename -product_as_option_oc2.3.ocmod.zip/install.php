<?php
/**
 * Products as product options
 * @author: nikita-sp.com.ua
 */

$chk = $this->db->query("SHOW COLUMNS FROM `" . DB_PREFIX . "product` WHERE `Field` = 'main_product'");

if (!$chk->num_rows) {
	$this->db->query("ALTER TABLE `" . DB_PREFIX . "product` ADD COLUMN  `main_product` INT NOT NULL DEFAULT  '0'");
	$this->db->query("CREATE TABLE IF NOT EXISTS `oc_product_field` (`product_field_id` int(11) NOT NULL AUTO_INCREMENT, `isselect` BOOLEAN NOT NULL DEFAULT TRUE, `format_string` VARCHAR(256) NOT NULL DEFAULT  '%field_value%', `sort_order` int(3) NOT NULL, PRIMARY KEY (`product_field_id`));");
	$this->db->query("CREATE TABLE IF NOT EXISTS `oc_product_field_description` (`product_field_id` int(11) NOT NULL, `language_id` int(11) NOT NULL, `name` varchar(64) COLLATE utf8_bin NOT NULL, PRIMARY KEY (`product_field_id`,`language_id`));");
	$this->db->query("CREATE TABLE IF NOT EXISTS `oc_product_field_value` (`product_id` int(11) NOT NULL, `product_field_id` int(11) NOT NULL, `language_id` int(11) NOT NULL, `value` text NOT NULL, `text` text NOT NULL, PRIMARY KEY (`product_id`,`product_field_id`,`language_id`));");
}
