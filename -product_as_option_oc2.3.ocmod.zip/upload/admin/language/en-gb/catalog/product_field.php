<?php
// Heading$_['heading_title']     = 'Product Fields';
// Text$_['text_success']      = 'Products fields are updated!';
$_['text_list']              = 'Product fields';
$_['text_add']               = 'Add';
$_['text_edit']              = 'Edit';
$_['text_plus']              = '+';
$_['text_minus']             = '-';

// Column$_['column_name']       = 'Field name';$_['column_sort_order'] = 'Sort order';$_['column_action']     = 'Action';
// Entry$_['entry_name']        = 'Field name:';
$_['entry_isselect']  = 'Select output:';
$_['entry_format_string']  = 'Format string:';$_['entry_sort_order']  = 'Sort order:';// Error$_['error_permission']       = 'Warning: You do not have permission to modify product fields!';
$_['error_name']             = 'Field Name must be greater than 3 and less than 64 characters!';?>