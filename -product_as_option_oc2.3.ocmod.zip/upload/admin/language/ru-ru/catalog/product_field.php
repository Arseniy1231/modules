<?php
// Heading$_['heading_title']     = 'Поля товаров';
// Text$_['text_success']      = 'Поля товаров успешно обновлены!';
$_['text_list']              = 'Поля товаров';
$_['text_add']               = 'Добавить';
$_['text_edit']              = 'Редактирование';
$_['text_plus']              = '+';
$_['text_minus']             = '-';
// Column$_['column_name']       = 'Название поля товара';$_['column_sort_order'] = 'Порядок сортировки';$_['column_action']     = 'Действие';
// Entry$_['entry_name']        = 'Название поля товара:';
$_['entry_isselect']  = 'Выводить как выпадающий список:';
$_['entry_format_string']  = 'Формат строки:';$_['entry_sort_order']  = 'Порядок сортировки:';// Error$_['error_permission']  = 'У Вас нет прав для изменения полей товаров!';$_['error_name']        = 'Название поля товара должно быть от 3 до 64 символов!';?>