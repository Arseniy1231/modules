<?phpclass ModelCatalogProductField extends Model{	public function addProductField($data){		$this->db->query("INSERT INTO " . DB_PREFIX . "product_field SET sort_order = '" . (int)$data['sort_order'] . "', isselect = '" . (int)$data['isselect'] . "', format_string = '" . $this->db->escape($data['format_string']) . "'");
		$product_field_id = $this->db->getLastId();
		foreach ($data['product_field_description'] as $language_id => $value) {			$this->db->query("INSERT INTO " . DB_PREFIX . "product_field_description SET product_field_id = '" . (int)$product_field_id . "', language_id = '" . (int)$language_id . "', name = '" . $this->db->escape($value['name']) . "'");		}	}
	public function editProductField($product_field_id, $data){		$this->db->query("UPDATE " . DB_PREFIX . "product_field SET sort_order = '" . (int)$data['sort_order'] . "', isselect = '" . (int)$data['isselect'] . "', format_string = '" . $this->db->escape($data['format_string']) . "' WHERE product_field_id = '" . (int)$product_field_id . "'");
		$this->db->query("DELETE FROM " . DB_PREFIX . "product_field_description WHERE product_field_id = '" . (int)$product_field_id . "'");
		foreach ($data['product_field_description'] as $language_id => $value) {			$this->db->query("INSERT INTO " . DB_PREFIX . "product_field_description SET product_field_id = '" . (int)$product_field_id . "', language_id = '" . (int)$language_id . "', name = '" . $this->db->escape($value['name']) . "'");		}	}
	public function deleteProductField($product_field_id){		$this->db->query("DELETE FROM " . DB_PREFIX . "product_field WHERE product_field_id = '" . (int)$product_field_id . "'");		$this->db->query("DELETE FROM " . DB_PREFIX . "product_field_description WHERE product_field_id = '" . (int)$product_field_id . "'");	}
	public function getProductField($product_field_id){		$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "product_field pf LEFT JOIN " . DB_PREFIX . "product_field_description pfd ON (pf.product_field_id = pfd.product_field_id) WHERE pf.product_field_id = '" . (int)$product_field_id . "' AND pfd.language_id = '" . (int)$this->config->get('config_language_id') . "'");
		return $query->row;	}
	public function getProductFields($data = array()){		$sql = "SELECT * FROM " . DB_PREFIX . "product_field pf LEFT JOIN " . DB_PREFIX . "product_field_description pfd ON (pf.product_field_id = pfd.product_field_id) WHERE pfd.language_id = '" . (int)$this->config->get('config_language_id') . "'";
		if (!empty($data['filter_name'])) {
			$sql .= " AND pfd.name LIKE '" . $this->db->escape($data['filter_name']) . "%'";
		}

		$sort_data = array(			'pfd.name',			'pf.sort_order'		);
		if (isset($data['sort']) && in_array($data['sort'], $sort_data)) {			$sql .= " ORDER BY " . $data['sort'];		} else {			$sql .= " ORDER BY pfd.name";   		}
		if (isset($data['order']) && ($data['order'] == 'DESC')) {			$sql .= " DESC";		} else {			$sql .= " ASC";		}		if (isset($data['start']) || isset($data['limit'])) {			if ($data['start'] < 0) {				$data['start'] = 0;			}			if ($data['limit'] < 1) {				$data['limit'] = 20;			}			$sql .= " LIMIT " . (int)$data['start'] . "," . (int)$data['limit'];		}		$query = $this->db->query($sql);		return $query->rows;	}	public function getProductFieldDescriptions($product_field_id){		$product_field_data = array();
		$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "product_field_description WHERE product_field_id = '" . (int)$product_field_id . "'");
		foreach ($query->rows as $result) {			$product_field_data[$result['language_id']] = array('name' => $result['name']);		}
		return $product_field_data;	}
	public function getTotalProductFields(){		$query = $this->db->query("SELECT COUNT(*) AS total FROM " . DB_PREFIX . "product_field");
		return $query->row['total'];	}
}