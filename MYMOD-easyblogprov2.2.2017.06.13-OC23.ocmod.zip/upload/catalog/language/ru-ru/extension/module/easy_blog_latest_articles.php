<?php
// Text
$_['button_read_more']           = 'Читать далее ...';
$_['heading_title']              = 'Последние статьи';
