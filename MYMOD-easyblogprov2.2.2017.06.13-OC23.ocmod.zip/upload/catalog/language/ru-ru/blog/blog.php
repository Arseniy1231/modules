<?php
// Text
$_['button_read_more']           = 'Читать дальше..';
$_['text_empty']                 = 'Нет статей';
$_['heading_tag']                = 'Тег - ';
$_['text_tag_result']            = 'Результаты поиска по тегу: ';