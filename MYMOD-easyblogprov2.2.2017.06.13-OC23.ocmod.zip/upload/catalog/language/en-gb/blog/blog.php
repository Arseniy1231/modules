<?php
// Text
$_['button_read_more']           = 'Read more ...';
$_['text_empty']                 = 'No articles';
$_['heading_tag']                = 'Tag - ';
$_['text_tag_result']            = 'Articles with tag: ';