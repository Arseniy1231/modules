<?php
// Text
$_['button_read_more']           = 'Read more ...';
$_['heading_title']              = 'Latest Articles';
