<?php
		
        $this->load->model('setting/setting');
        $this->load->model('user/user_group');
		$this->load->model('design/layout');

        $this->model_user_user_group->addPermission($this->user->getGroupId(), 'access', 'blog/article');
        $this->model_user_user_group->addPermission($this->user->getGroupId(), 'modify', 'blog/article');
		$this->model_user_user_group->addPermission($this->user->getGroupId(), 'access', 'blog/blog_category');
        $this->model_user_user_group->addPermission($this->user->getGroupId(), 'modify', 'blog/blog_category');
        $this->model_user_user_group->addPermission($this->user->getGroupId(), 'access', 'blog/comment');
        $this->model_user_user_group->addPermission($this->user->getGroupId(), 'modify', 'blog/comment');
		$this->model_user_user_group->addPermission($this->user->getGroupId(), 'access', 'blog/setting');
        $this->model_user_user_group->addPermission($this->user->getGroupId(), 'modify', 'blog/setting');
        $this->model_user_user_group->addPermission($this->user->getGroupId(), 'access', 'extension/module/easy_blog_latest_articles');
        $this->model_user_user_group->addPermission($this->user->getGroupId(), 'modify', 'extension/module/easy_blog_latest_articles');
        $this->model_user_user_group->addPermission($this->user->getGroupId(), 'access', 'extension/module/easy_blog_category_menu');
        $this->model_user_user_group->addPermission($this->user->getGroupId(), 'modify', 'extension/module/easy_blog_category_menu');

        $easy_blog_settings = array(
            'easy_blog_global_article_limit'              => '10',
            'easy_blog_global_status'                     => '1',
			'easy_blog_home_page_name'    	              => 'Blog',
            'easy_blog_home_page_meta_title'              => 'Blog',
            'easy_blog_home_page_meta_description'        => '',
            'easy_blog_home_page_meta_keyword'            => '',
            'easy_blog_home_page_description'             => '',
            'easy_blog_home_page_seo_url'                 => 'easy_blog',
            'easy_blog_home_page_show_date'               => '1',
            'easy_blog_home_page_show_author'             => '1',
            'easy_blog_home_page_show_viewed'             => '1',
            'easy_blog_home_page_show_number_of_comments' => '1',
            'easy_blog_home_page_show_category'           => '1',
            'easy_blog_home_page_show_tag'                => '1',
            'easy_blog_category_show_date'                => '1',
            'easy_blog_category_show_author'              => '1',
            'easy_blog_category_show_viewed'              => '1',
            'easy_blog_category_show_number_of_comments'  => '1',
            'easy_blog_category_show_category'            => '1',
            'easy_blog_category_show_tag'                 => '1',
            'easy_blog_article_show_date'                 => '1',
            'easy_blog_article_show_author'               => '1',
            'easy_blog_article_show_viewed'               => '1',
            'easy_blog_article_show_number_of_comments'   => '1',
            'easy_blog_article_show_category'             => '1',
            'easy_blog_article_show_tag'                  => '1',
            'easy_blog_comment_config_status'             => '1',
            'easy_blog_comment_config_guest'              => '0',
            'easy_blog_comment_config_approve'            => '1',
            'easy_blog_comment_config_mail'               => '0',
            'easy_blog_comment_captcha_status'            => '0',
            'easy_blog_comment_captcha_public'            => ($this->config->has('config_google_captcha_public')?$this->config->get('config_google_captcha_public'):''),
            'easy_blog_comment_captcha_secret'            => ($this->config->has('config_google_captcha_secret')?$this->config->get('config_google_captcha_secret'):''),
            'easy_blog_comment_order'                    => 'ASC'
        );

        $this->model_setting_setting->editSetting('easy_blog', $easy_blog_settings, 0);
		
		$easy_blog_layout = array(
            'name' => 'Easy Blog',
            'layout_route' => array(
				'first_route' => array(	
					'store_id' => '0',
					'route' => 'blog/%'
				)
			)
        );
		$this->model_design_layout->addLayout($easy_blog_layout);
		
?>